//
//  xmcomm.h
//  xmcomm
//
//  Created by Ferdinand Urban on 16/03/16.
//  Copyright © 2016 xmarton, s.r.o. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for xmcomm.
FOUNDATION_EXPORT double xmcommVersionNumber;

//! Project version string for xmcomm.
FOUNDATION_EXPORT const unsigned char xmcommVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <xmcomm/PublicHeader.h>


